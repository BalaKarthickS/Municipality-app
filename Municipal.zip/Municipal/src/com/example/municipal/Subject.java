package com.example.municipal;

/**
 * Created by Juned on 1/30/2017.
 */

public class Subject {

    public String Subject_Name;
    public String Subject_Full_Form;
    public String Subject_Full_Form1;
    public String Subject_Full_Form2;
    public String Subject_Full_Form3;
    public String Subject_Full_Form4;
    public String Subject_Full_Form5;
    public String Subject_Full_Form6;
    public String Subject_Full_Form7;
    public String Subject_Full_Form8;
    public String Subject_Full_Form9;
}
