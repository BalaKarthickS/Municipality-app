package com.example.municipal;

import java.util.ArrayList;



import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity1 extends Activity {

	 GridView gv;
     Context context;    
        ArrayList prgmName;    
        String[] web = {
    		    "Electricity",
    			"Water",
    			"Drainage",
    			"Garbage",
    			"Road",
    			"Others"
    			

    	} ;
    	int[] imageId = {
    			R.drawable.gic1,
    			R.drawable.gic2,
    			R.drawable.gic3,
    			R.drawable.gic4,
    			R.drawable.gic5,
    			R.drawable.gic6
    			

    	};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Intent hh=getIntent();
        String una=hh.getStringExtra("uname");
        String pwd=hh.getStringExtra("pass");
       // Toast.makeText(getApplication(), una+pwd, Toast.LENGTH_LONG).show();
        gv=(GridView) findViewById(R.id.gridView1);      
        gv.setAdapter(new CustomAdapter1(this, web,imageId,una,pwd));
    }


    
}
