package com.example.municipal;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Otp extends Activity {

	Button btn;
	 EditText ed1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_otp);
		
		  Intent hh=getIntent();
		  final String una=hh.getStringExtra("uname");
	        final  String pwd=hh.getStringExtra("pass");
	       final String pwd1=hh.getStringExtra("otp");
	        
	       ed1=(EditText)findViewById(R.id.editText1);
	        
	        btn=(Button)findViewById(R.id.button1);
	        
	        btn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					
					
					if(ed1.getText().toString().equals(pwd1))
					{
						Intent bb=new Intent(Otp.this,MainActivity.class);
                		bb.putExtra("uname", una);
                		bb.putExtra("pass", pwd);                  	           		

                		startActivity(bb);
					}else
					{
					
						Toast.makeText(getBaseContext(), "OTP NUMBER NOT VALID", Toast.LENGTH_LONG).show();
					}
					
					
					
				}
			});
	        

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.otp, menu);
		return true;
	}

}
