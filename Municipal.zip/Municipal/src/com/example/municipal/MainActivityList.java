package com.example.municipal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;


public class MainActivityList extends Activity {

    ListView SubjectFullFormListView;
    ProgressBar progressBar;
    String HttpURL;// = "http://sputnikinfotech.com/test_android/SubjectFullForm.php";
    ListAdapter adapter ;
    List<Subject> SubjectFullFormList;
    EditText editText ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_main_list);
        
         Intent hh=getIntent();
	     final   String una=hh.getStringExtra("uname");
	     final  String pwd=hh.getStringExtra("pass");
	     final  String ty=hh.getStringExtra("vv");
	     
	     if(ty.equals("A"))
	     {
	    	 HttpURL = "http://sputnikinfotech.com/test_android/MU/SubjectFullForm1.php";
	     }else if(ty.equals("B"))
	     {
	    	 HttpURL = "http://sputnikinfotech.com/test_android/MU/SubjectFullForm2.php";
	     }else if(ty.equals("C"))
	     {
	    	 HttpURL = "http://sputnikinfotech.com/test_android/MU/SubjectFullForm3.php";
	     }else if(ty.equals("D"))
	     {
	    	 HttpURL = "http://sputnikinfotech.com/test_android/MU/SubjectFullForm4.php";
	     }
	     else if(ty.equals("E"))
	     {
	    	 HttpURL = "http://sputnikinfotech.com/test_android/MU/SubjectFullForm5.php";
	     }
	     else if(ty.equals("F"))
	     {
	    	 HttpURL = "http://sputnikinfotech.com/test_android/MU/SubjectFullForm6.php";
	     }
        SubjectFullFormListView = (ListView) findViewById(R.id.SubjectFullFormListView);

        //editText = (EditText)findViewById(R.id.edittext1);

        progressBar = (ProgressBar) findViewById(R.id.ProgressBar1);

        new ParseJSonDataClass(this).execute();
        
        //Toast.makeText(getApplication(), ""+HttpURL, Toast.LENGTH_LONG).show();


    }

    private class ParseJSonDataClass extends AsyncTask<Void, Void, Void> {
        public Context context;
        String FinalJSonResult;

        public ParseJSonDataClass(Context context) {

            this.context = context;
        }

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            HttpServiceClass httpServiceClass = new HttpServiceClass(HttpURL);

            try {
                httpServiceClass.ExecutePostRequest();

                if (httpServiceClass.getResponseCode() == 200) {

                    FinalJSonResult = httpServiceClass.getResponse();

                    if (FinalJSonResult != null) {

                        JSONArray jsonArray = null;
                        try {

                            jsonArray = new JSONArray(FinalJSonResult);
                            JSONObject jsonObject;
                            Subject subject;

                            SubjectFullFormList = new ArrayList<Subject>();

                            for (int i = 0; i < jsonArray.length(); i++) {

                                subject = new Subject();

                                jsonObject = jsonArray.getJSONObject(i);

                                subject.Subject_Name = jsonObject.getString("username");

                                subject.Subject_Full_Form = jsonObject.getString("password");

                                subject.Subject_Full_Form1 = jsonObject.getString("email");

                                subject.Subject_Full_Form2 = jsonObject.getString("ph");

                                subject.Subject_Full_Form3 = jsonObject.getString("typ");

                                subject.Subject_Full_Form4 = jsonObject.getString("trno");

                                subject.Subject_Full_Form5 = jsonObject.getString("tramt");

                               // subject.Subject_Full_Form6 = jsonObject.getString("tbank");

                               // subject.Subject_Full_Form7 = jsonObject.getString("tdate");

                                //subject.Subject_Full_Form8 = jsonObject.getString("st1");

                               // subject.Subject_Full_Form8 = jsonObject.getString("st2");

                                SubjectFullFormList.add(subject);
                            }
                        } catch (JSONException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                } else {

                    Toast.makeText(context, httpServiceClass.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result)

        {
            progressBar.setVisibility(View.GONE);

            SubjectFullFormListView.setVisibility(View.VISIBLE);

                adapter = new ListAdapter(SubjectFullFormList, context);

                SubjectFullFormListView.setAdapter(adapter);

            SubjectFullFormListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                	String roll = ((TextView) view.findViewById(R.id.rollno))
							.getText().toString();
					String name = ((TextView) view.findViewById(R.id.username))
							.getText().toString();
					String dept = ((TextView) view.findViewById(R.id.dept))
							.getText().toString();
					String ph = ((TextView) view.findViewById(R.id.phone))
							.getText().toString();
					String pname = ((TextView) view.findViewById(R.id.pname))
							.getText().toString();
					String address = ((TextView) view.findViewById(R.id.address))
							.getText().toString();
                	
                	
                	Intent vv=new Intent(getApplicationContext(),Feed_part.class);
                	vv.putExtra("roll", roll);
                	vv.putExtra("name", name);
                	vv.putExtra("dept", dept);
                	vv.putExtra("ph", ph);
                	vv.putExtra("pname", pname);
                	vv.putExtra("address", address);
					startActivity(vv);

                }
            });

        }
    }

}